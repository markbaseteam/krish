![[welcome hello krish.png]]
I know this intro is supposed to be something deep and meaningful about how cool I am. In reality, ==I'm just a humble guy who likes to make things and solve problems.==

- I play with a lot of tools and concepts because it is fun to play and try things out. I enjoy the challenge of figuring out how to solve for new things.

- I try to break down complex stuff into simple visual things that’s easy to articulate and understand. It just helps bringing teams together.

- I love the role of a ==servant leader working at the intersection of business, design and engineering==. Some people like the stuff I make and sometimes give me awards and occasionally hire me to make things for them.

- Though I started coding 20 years ago, I moved into customer facing roles when I realized a knack for sharing ideas and techniques in a relatable way. Solving user problems has become my passion since then.

- I’ve helped users find solutions to their challenges in the ==Billing, Payments and Revenue recognition space for Enterprises== for the past 10+ years. This has given me the opportunity to listen to users, analyze their pain points, research the market, conceptualize solutions, get buy-in from leaders and enable engineering teams execute the vision.

