# Krishnan Minnalur Shankarnarayanan
![[Header_2.png]]
> [!tip] B2B product management with 19+ years of industry experience. 
> I currently lead 3 engineering agile teams at **Oracle**. 
> My team and I manage partner sales technology platforms that handles 5B+ in transactional and recurring revenue.

## **Intro** 
 🖐  I know this intro is supposed to be something deep and meaningful about how cool I am. In reality, I'm just a humble guy who likes to make things and solve problems. I break down complex stuff into simple visual things that’s easy to articulate and understand. I enable teams to come together and solve problems. I love the role of a servant leader working at the intersection of business, design and engineering. Some people like the stuff I make and sometimes give me awards and occasionally hire me to make things for them. I’ve helped users find solutions to their challenges in the Billing, Payments and Revenue recognition space for Enterprises for the past 10+ years. This has given me the opportunity to listen to users, analyze their pain points, research the market, conceptualize solutions, get buy-in from leaders and enable engineering teams execute the vision.

**Role**: ==Product manager==
**Led Teams:** ==Yes==
**Technical:** ==Yes==
**Program Management:** ==Yes==

# Work Experience
## Oracle 
### Mar 2020 - Present 
**Cloud Solutions Director** 

GPSO (Global Partner Sales Organization) Product Management at Oracle manages Partner Sales technology that handles 5B+ in revenue annually across all our VAD, VAR, ISV, SI's and CSPs . The platform comprises of Partner Sales automation applications that begins from the public OPN pages (Oracle Partner Network), Oracle Partner Store for Opportunity management, deal registrations,  quoting, Royalty management, Expertise and Competency Center

**My role** is to work with stakeholders across Partners, GPSO business, design and engineering to understand business pain points. Once they are broken down into business requirements, I analyze these requirements and use RICE/WSJF scoring to prioritize these requirements in collaboration with business and engineering teams. Depending on the scope of work, I phase out projects in multiple releases and helps plan my roadmap. I  groom epics, features and stories, work with design UI/UX teams to finalize designs, enable engineering teams by unblocking impediments and help business teams understand product mechanics
#### Projects
#####  Accelerated Buying Experience for Partners 
**Problem**
- As part of a weekly forum, business and product management analyze trends in buying experience. During these forums, we discovered the following buying trends
	- Online acceptance - 66%
	- Offline acceptance - 34%
- On further analysis, I discovered following reasons contributed to 34% offline acceptance 
		- Excluded LAD orders
		- Co-term and expansion deal exclusions
		- Product restrictions (e.g. advertising orders cannot be checked out online)
		- Mandatory documentation requirements (e.g. Partner due diligence report)
- After diving deep into each topic, we came to a consensus that Mandatory document requirements can be solved for quickly that can bring down offline acceptance by a whopping 12%. 


> [!summary] **Sample Rice Scoring** 

Priority | Feature | Reach | Impact | Confidence | Effort | Score
---|---|---|---|---|---|---
1| Accelerated Buying | 77 | 5 | 90% | 5 | 69.3
2| Pro-forma invoicing | 65 | 3 | 72% | 3 | 46.8
3| Support Credits | 55 | 5 | 81% | 5 | 44.6
4| Extensions | 48 | 3 | 60% | 4 | 21.6
5| Academy Store | 37 | 2 | 43% | 2 | 15.9



