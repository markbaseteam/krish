![[Header_2.png]]
## Oracle
**Cloud Solutions Architect**
Mar 2020 - Present
- Product leader responsible for roadmap, strategy and execution
- Managed strategic partnerships and partner ecosystem with VADs, Resellers, ISV’s. Launched end to end reseller commerce for Cloud, SaaS, IaaS and PaaS products (Oracle OCI)
- Launched a new product and revenue stream with 500% YoY growth from $3 million to $80 million in Annual Contract Value (ACV) in 2 years. The Accelerated Buying Commerce initiative involved 20+ internal and external stakeholder groups from product teams, business functions, partners and customers
- Led product operations and training initiatives to improve key product management processes and tools including quarterly product planning, monthly product delivery updates, agile training for product and engineering teams, customer webinars, roadmap commitment tracking and product career matrix to improve effectiveness of product management organization
- Hired and built a brand new product team of 6 product managers in the USA, Canada, Hungary and India. Worked with engineering leadership to scale corresponding global engineering from 2 scrum teams to 9 scrum teams
- Led product initiatives to launch headless developer center for customers and ISV partners using REST and GraphQL APIs
- Reduced order errors from 15% to <1% within a FY to improve customer NPS, retention and revenue by leading initiatives to identify issues with order capture and provisioning, analyze root causes and implement the solution
### Projects
